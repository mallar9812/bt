# brian-exp-11

## v1.8.4: fix plugin.json

- `.claude-plugin/plugin.json` was saved empty by the v1.8.1 to v1.8.3 packaging (the version bump truncated it), so the plugin failed validation ("Invalid JSON"). Restored with the same name, description and author, version 1.8.4. No other file is affected (all other JSON files and every non-empty file checked).

## v1.8.3: chat carries only the Verdict once the dashboard is built

- For a user-started full or targeted read, the dashboard is published first and the chat then shows the Verdict only (a targeted read: its requested-metric and movement sections), the dashboard link, and state lines for any area not run. The Summary table, Experiment Card, headline, charts and the other sections are no longer written in chat; Part 2 adds a single closing line. The "High-level or detailed?" wording question is not asked when a dashboard will be built. Reads with no dashboard (special states, period reads, stream-origin) keep their full chat report. `report-generator.md` § Chat answer when a dashboard is built, `two-part-read.md`, `dashboard.md`, `SKILL.md`, `template-population.md`, `progress-table.md`. Documentation only; not exercised on a real read.

## v1.8.2: confirm the experiment when the request is vague

- New first step of a user-started read (`references/experiment-confirmation.md`, `SKILL.md` step 0a, `context-resolution.md` steps 2 and 8, `master-state.md` `experiment_confirmation`). A clear request (exact name or `exp_id`, game and platform, one matching name) is restated in one line and goes on with no question. A vague one (loose fragment, several or approximate matches, missing game or platform, a version that matches nothing) runs only the bounded candidates probe and asks which experiment (up to four nearest, each with game, platform, `exp_id`, latest version, dates and arms), plus platform and version only when unclear. Unattended, scheduled and stream-origin reads never ask: one match proceeds with the interpretation stated, otherwise nothing starts and the candidates are reported. Documentation only; not exercised on a real read.

## v1.8.1: the audience questions are optional

- The second setup call is now one question: "Do you want to see the data at any filter or cut (user type, payer status, cohorts)?" with No, all users (Recommended), Yes pre-select on the dashboard (lens), or Yes run the entire read for that cut only (scope). Only a Yes opens the follow-up with user type, payer status and cohorts. No stores nothing and leaves the read and dashboard unchanged. `analysis-area-selection.md`, `SKILL.md`. Documentation only; the dashboard code is unchanged.

## v1.8.0: weighted PAB, and a Druid-only data option

- **PAB is now weighted by old-user share.** Adjusted effect = observed − (old-user share × PAB), with the PAB half-width scaled by the same share, so the interval is √(h_obs² + (share × h_pab)²). `old_share` is the result's own share of DAU-days from `user_type = old` users (both variants pooled, same scope and cut as the result). Old-user cuts use the full PAB (share 1); new-user cuts and D00 to D30 cohorts have none (share 0, observed †); payer cuts, puzzle types and the all-users rows use their own share. If the share cannot be computed the result is `NOT_COMPUTABLE_NO_OLD_SHARE` (observed †), never the full PAB. Changed: `stats_common.adjust(..., old_share)` plus tests, `analysis-contract.md` § PAB adjustment, all `analyses/*.md` PAB sections, `capability-result.md` (`old_share` field), `master-state.md`, `dashboard.md`, UI spec, `summary-table.md`, Method text in the page body example, and `page.js` (the Summary table's recomputed view applies the share; the tooltip shows "PAB × NN% old users").
- **Druid-only data question.** The setup call has a fourth question, "Fetch experiment data only from Druid?", Yes (default, recommended) or No. Yes: every statement runs on Druid; a Druid outage blocks the unit (`DRUID_UNAVAILABLE`), nothing is substituted. No: Druid first, Trino MCP allowed for tables not in Druid or after a Druid failure, one engine per result, engine logged per statement in `queries.log` and named in Method. Stored as `data_source`; passed to every worker. Unattended, scheduled and stream-origin reads default to Yes. Annotations (`play_data.charts_annotations`, Databricks only) are not experiment data and keep their own engine. `analysis-area-selection.md`, `SKILL.md`, `master-state.md`, `parallel-dispatch.md`, `ps-data-catalog/references/query-engines.md`.
- Not exercised: a real read through the new `old_share` Stage 1 statement and through the Trino path. The live dashboard (stored results) still shows unweighted PAB values until its datasets are recomputed.

## v1.7.3: a colored dot for every variant

- Every variant now has its colored dot (var3 to var8 as well as var1 and var2): table headers, headline tile rows and trend lines; the reference column also has var1's dot. The Summary table's recomputed view and the "New users by days since install" card now show one column / table per variant pair (they showed only the first pair). `page.css`, `page.js` (`ARMC` built from the variants present), `dashboard.md` § Variant dots and check 22. Pushed to the live dashboard.
- Tested in headless Chromium with synthetic var3 and var4 data (distinct dots on three pair headers and three cohort tables; computed colors checked for var1 to var6; var7 and var8 use fixed fallbacks). A real multi-variant read was not run; single-variant output is unchanged.


## v1.7.2: simpler Summary table controls

- Only four dropdowns above the Summary table: Cohort, User type, Payer flag and Metrics (metric groups, like the Matrix), all ticked by default, plus Reset (and Target audience when set). "Split across" and the separate selects are gone. A Metrics subset also filters the stored all-users table. Engine group names for economy now match the stored table. Pushed to the live dashboard. Tested in headless Chromium (no errors; Old/New, payer, cohort and metric-group selections, audience preset).


## v1.7.1

- The audience question has a fourth part: "Pre-select it on the dashboard and lead with it" (default, the read stays for all users) or "Run the entire read for this audience only". The second is sent as `segment_ref` through the existing scope path (context-resolution step 2b, routed as TARGETED_DIAGNOSIS), nothing broadened. `analysis-area-selection.md`, `master-state.md` (`target_audience.apply`), `SKILL.md`, `dashboard.md`. The scoped path is documented but not exercised end to end.


## v1.7.0: ask who the experiment is for

- Straight after the analysis-area question, the Master asks whether the experiment is for a specific audience: user type (all / new / old), payer status (all / payers / non-payers) and cohorts (all / D00-D30 / D31 and later / specific ones via Other). Default is all users; skipped when the request already says. `analysis-area-selection.md` § Target audience, `SKILL.md` step 0, `master-state.md` (`target_audience`).
- It is a focus lens, not a filter: no result is dropped or re-scoped. The chat Summary gets a "Target audience" block for a single cut, the Verdict leads with the audience then all users, and the dashboard opens its Summary table on the audience (new `audience` dataset; "Target audience" and "Reset (all users)" buttons). Experiment card row added.
- Tested in headless Chromium with a mock `audience` row (opens on new users, Reset and the audience button both work, no row means all users, no script errors). Not run on a live read; the live dashboard was not changed.


## v1.6.1

- The analysis-area question shows all eight areas and "All 8 areas" together in one call (a single choice plus two tick-lists of four), with no "Let me choose" second round. `analysis-area-selection.md` § How it is asked; `SKILL.md` step 0.


## v1.6.0: ask which analysis areas before a full read starts

- Before a user-origin FULL_EXPERIMENT_READ starts any query, the Master asks which of the 8 analysis areas to include (Revenue, Rolling retention, Engagement, Sessions, Classic retention, LTV and LTDays, Rolling LTV, Economy). "All 8 areas" is the first option and the default; "Let me choose" opens up to two multi-select questions (the question tool allows four options each). New file `references/analysis-area-selection.md`; `SKILL.md` step 0; `master-state.md` (`capability_selection`, `SKIPPED_NOT_SELECTED`); `two-part-read.md`; `dashboard.md` (§ Unselected analysis areas).
- Unselected areas are never dispatched or charged; the report and dashboard leave out what only they can fill and name them in Guardrails. Not asked when the request already names areas or says all, when unattended, or in TARGETED, PERIOD and stream-origin runs.
- Note: the request said "7 metrics"; the registry has 8 capabilities and no set of 7, so the 8 areas are used. Not run end to end on a live read, docs only. The progress table already handles skipped steps.


## v1.5.0: collapsible sections, hover notes, old users, one Summary table

- Every section can be collapsed (chevron on the heading, Collapse all / Expand all under the header); the Experiment card is collapsed by default; nav links expand their target.
- Header: "All effects are PAB-adjusted" and "Scope" are short underlined texts with the remainder on hover. Headline results: only "† = observed, PAB not available" is visible; the rest is in an "i" hover button.
- "Old users" replaces "established users" everywhere a user type is meant, in the page and in the analysis and report docs. New means `user_type = new` and old means `user_type = old`, stated in the table headers, the select options and the "New users by days since install" card.
- "New users by days since install" is now computed on the page from the daily cut data with `user_type = new` (observed †) instead of stored cohort cells; its numbers match the stored cohort cells.
- The Segment explorer is merged into the Summary table: User type, Payer status, Cohorts (dropdown checklist), Split across, Metrics and Reset above the table; the default view is the stored all-users table. The Explore section and nav link are gone.
- `ok()` tolerates a missing dataset. `page.body.example.html` is replaced by the current body (fixes its stale wording).
- Verified in headless Chromium against this read's real datasets: no script errors, collapse and nav behaviour, hover notes, the cohort and user-type numbers equal the stored values. Not verified: a phone-width layout, dark mode, other experiments.

## v1.4.0: fewer approvals, both parts always run

- Datasets travel as one bundle (`scripts/build_bundle.py`; `ok()` in `page.js` splits rows by `_ds`, with a fallback to separate documents). A dashboard publish is now: create from type, one upload, one batched `ArtifactData` write (page and bundle together); Part 2 is one upload and one write. About 25 approvals become about 5, and none if the user picks allow for this session. The host app's approvals cannot be granted by the plugin; the Master says this once at the start.
- Both parts always run: Part 2 starts by itself right after Part 1 is delivered, with no question and no pause; only an explicit user stop ends the read after Part 1 (`two-part-read.md`).
- Verified: bundle round trip (all 19 datasets, 59 results, 529 cells) and the page shim in Node. Not verified on screen.

## v1.3.1

- Matrix: all metric groups are selected by default and always shown together, each group's metrics under its own heading row (the heading is shown also when a single group is selected). `page.js`, `dashboard.md` check 14, `assets/README.md`.

## v1.3.0: two-part read (standing behaviour)

Every user-origin FULL or TARGETED read that gets a dashboard now runs in two parts, always, in sequential and parallel dispatch alike (`skills/experiment-master/references/two-part-read.md`).
- **Part 1** is everything outside the dashboard's Appendix: Stage 1 for every capability plus the Stage 2 items behind the Verdict, Users, Segment explorer and Puzzle types. It is delivered first, in chat as the Summary table (`summary-table.md` § Detailed Read table, priority rows first) with the dashboard link, and the dashboard is published with the Appendix showing "Part 2 is running".
- **Part 2** is a second pass over the same frozen context: the remaining Stage 2 items, Stage 3+ and follow-ups, then the rest of the Detailed Read in chat, and the Appendix datasets (`cells` in full, `trends`, `trend_pab`) written in place on the same artifact. No page republish.
- Context is resolved once. Totals, budgets, statistics and classification are those of a single-pass read; only the order of work and of delivery changes. Budget order inside `mandatory`: Stage 1, then Part 1 Stage 2 items, then Part 2 items; slices split into a Part 1 and a Part 2 slice (`master-state.md`, `parallel-dispatch.md` § 2).
- New dataset `run_state` (`part2` = RUNNING / COMPLETE / PARTIAL) and `applyRunState()` in `page.js`; the Appendix is hidden until Part 2 completes. No `run_state` means complete, so existing pages are unaffected.
- Progress table: `<id>_p1` / `<id>_p2` steps, `part` field, and a footer with the time to Part 1 and to the whole read. Baselines are split between the parts by estimate and are to be replaced by the first measured two-part read.
- Estimated effect on the reference read (baselines): the Summary arrives at about 19 min instead of about 35 min (parallel) and about 29 min instead of about 56 min (sequential); the whole read ends at about the same time (about +0.5 min parallel, -0.5 min sequential).


Based on brian-exp-9 v1.6.1. What is new relative to the original brian-exp-9:

**Experiment-read dashboard**
- Clear/DAU is in the headline set. The Verdict has no Scope row.
- "New users by days since install" is optional: the page asks first and shows it only on a yes.
- "All cells" and "Every result" show the variant pair in the row header (`<metric> · var2 vs var1`), no Pair column.
- Both tables have Variants and Fields dropdown checklists. Default fields: Capability (Every result only), Exp change, % change (PAB-adj.). The reading tag of the observed effect sits next to Exp change, the PAB-adjusted tag next to % change. There are no Reading columns.
- The Matrix is one table with one line per selected variant per metric, a Variants dropdown, and a multi-select Metric groups dropdown.
- The design rules and the verdict-reaching rules in `report-generator/dashboard.md` are mandatory.

**Parallel dispatch (optional, default off)**
- `skills/experiment-master/references/parallel-dispatch.md`: frozen `run/context.json`, isolated read-only capability workers, merge checks (hash, schema, row counts, re-classification, raw-row spot checks), failure handling and a parity gate.
- Parallel runs get `parallel_budget_uplift` (default 20%) more budget; slices = Stage 1 floor + surplus shared by `metrics × (1 + cuts)`, capped at demand, with a 20% Master reserve (`references/master-state.md` § Budget).
- `skills/experiment-master/scripts/stats_common.py` and `stats_common_test.py`: one shared implementation of the paired test, PAB adjustment and classification.
- Follow-up waves (`parallel-dispatch.md` § 5): independent follow-ups, meaning different capabilities with no dependency between them, can run as a further wave of workers, paid from the reserve and returned slices, merged with the same checks. The follow-up decisions stay with the Master.

**Live progress table**
- `references/progress-table.md`, `scripts/progress_table.py`, `scripts/progress_baselines.json`: a table of steps with state, elapsed time and approximate time remaining, shown at every step change. Baselines come from a measured read and are rescaled by the observed pace; parallel runs are estimated with greedy worker slots. Worker heartbeats feed it.
